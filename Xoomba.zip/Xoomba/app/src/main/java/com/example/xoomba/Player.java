package com.example.xoomba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

import static com.example.xoomba.R.drawable.ic_favorite_black_24dp;
import static com.example.xoomba.R.drawable.ic_favorite_border_black_24dp;

public class Player extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, MediaPlayer.OnCompletionListener{

    TextView tv,timestart,timeend;
    Button play,next,prev;
    ArrayList<File> mysongs;
    String msongname;
    int position;
    public static MediaPlayer mediaPlayer;
    ImageView logo,fav,logo1;
    SeekBar seekBar;
    int count=0;
    Handler handler;
    Runnable runnable;
    String songname;
    MediaMetadataRetriever mediaMetadataRetriever;
    String s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        tv = findViewById(R.id.tv1);
        play = findViewById(R.id.play);
        next = findViewById(R.id.next);
        prev = findViewById(R.id.prev);
        logo = findViewById(R.id.logo);
        logo1=findViewById(R.id.logo1);
        fav = findViewById(R.id.fav);
        timeend = findViewById(R.id.timeend);
        timestart = findViewById(R.id.timestart);
        seekBar = findViewById(R.id.seek);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        mysongs = (ArrayList) bundle.getParcelableArrayList("song");
        position = bundle.getInt("pos", 0);
        msongname = mysongs.get(position).getName();
        songname = intent.getStringExtra("name");
        MyDatabase md = new MyDatabase(Player.this);
        ArrayList<String> arrayList = md.showSongs();
        if (arrayList.contains(songname)) {
            fav.setImageResource(ic_favorite_black_24dp);
            count = 1;
        } else {
            fav.setImageResource(ic_favorite_border_black_24dp);
            count = 0;
        }
        tv.setText(songname);
        tv.setSelected(true);
        Uri uri = Uri.parse(mysongs.get(position).toString());
        mediaPlayer = MediaPlayer.create(Player.this, uri);
        //mediaPlayer.start();

        if (mediaPlayer != null) {
            String y = (ConvertToDuration(mediaPlayer.getDuration()));
            timeend.setText(y);
            // Toast.makeText(this, ""+y, Toast.LENGTH_SHORT).show();
        }
        SongData songData = new SongData(getApplicationContext());
        songData.settmode(1);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    play.setBackgroundResource(R.drawable.ic_play_circle_filled_black_24dp);
                    mediaPlayer.pause();
                } else {
                    play.setBackgroundResource(R.drawable.ic_pause_circle_filled_black_24dp);
                    mediaPlayer.start();
                }
            }
        });
        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count == 1) {
                    Toast.makeText(Player.this, "Removed from Favoutites", Toast.LENGTH_SHORT).show();
                    fav.setImageResource(ic_favorite_border_black_24dp);
                    MyDatabase mdd = new MyDatabase(getApplicationContext());
                    String name = songname;
                    mdd.doDelete(name);
                    count = 0;
                } else {
                    Toast.makeText(Player.this, "Added to Favoutites", Toast.LENGTH_SHORT).show();
                    fav.setImageResource(ic_favorite_black_24dp);
                    MyDatabase mdd = new MyDatabase(getApplicationContext());
                    String name = songname;
                    File song = mysongs.get(position);
                    mdd.addSong(name, song, position);
                    count = 1;
                }
            }
        });
        seekBar.setOnSeekBarChangeListener(Player.this);
        seekBar.setMax(mediaPlayer.getDuration());
        mediaPlayer.start();
        setPlay();
        new Thread() {
            public void run() {
                if(mediaPlayer!=null)
                {
                    while (mediaPlayer.getCurrentPosition() != mediaPlayer.getDuration()) {
                        seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    }

                }
            }

        }.start();
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playPrevious();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               playNext();
                //Toast.makeText(Player.this, ""+msongname, Toast.LENGTH_SHORT).show();

            }
        });
        mediaPlayer.setOnCompletionListener(Player.this);
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected  void onStop() {
        super.onStop();
    }
    public MediaPlayer st()
    {
        MediaPlayer mp=mediaPlayer;
        return mp;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    String ConvertToDuration(long dur) {
        String d="";
        dur=dur/1000;
        d=d+dur/60+":"+dur%60;
        return d;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if(fromUser)
        {
            mediaPlayer.seekTo(progress);
        }
        timestart.setText(ConvertToDuration(mediaPlayer.getCurrentPosition()));
        timeend.setText(ConvertToDuration(mediaPlayer.getDuration()-mediaPlayer.getCurrentPosition()));
    }
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    //handler.removeCallbacks(runnable);
    }
    public void setPlay()
    {
       try
       {
          // Toast.makeText(this, ""+(mysongs), Toast.LENGTH_SHORT).show();
           mediaMetadataRetriever=new MediaMetadataRetriever();
         mediaMetadataRetriever.setDataSource(Player.this,Uri.parse(String.valueOf(mysongs.get(position))));
          byte[] ar=mediaMetadataRetriever.getEmbeddedPicture();
           if(ar!=null)
           {
               Bitmap b = BitmapFactory.decodeByteArray(ar, 0, ar.length);
               Drawable d = new BitmapDrawable(getResources(), b);
               logo1.setBackground(d);
               logo1.setVisibility(View.VISIBLE);
               logo.setVisibility(View.INVISIBLE);
           }
           else {
               logo.setImageResource(R.drawable.music1);
               logo1.setVisibility(View.INVISIBLE);
               logo.setVisibility(View.VISIBLE);

           }
       }
       catch (Exception e)
       {
           Toast.makeText(this, "fucked", Toast.LENGTH_SHORT).show();
       }
    }
    public void playNext()
    {

        //Toast.makeText(this, "ishan", Toast.LENGTH_SHORT).show();
        position=position+1;
        msongname=mysongs.get(position).getName();
        mediaPlayer.pause();
        mediaPlayer.stop();
        MyDatabase md = new MyDatabase(Player.this);
        ArrayList<String> arrayList = md.showSongs();
        if (arrayList.contains(msongname)) {
            fav.setImageResource(ic_favorite_black_24dp);
            count = 1;
        } else {
            fav.setImageResource(ic_favorite_border_black_24dp);
            count = 0;
        }
        //mediaPlayer=new MediaPlayer()
        tv.setText(msongname);
        tv.setSelected(true);
        Uri uri = Uri.parse(mysongs.get(position).toString());
        mediaPlayer = MediaPlayer.create(Player.this, uri);
        //mediaPlayer.start();

        if (mediaPlayer != null) {
            String y = (ConvertToDuration(mediaPlayer.getDuration()));
            timeend.setText(y);
            // Toast.makeText(this, ""+y, Toast.LENGTH_SHORT).show();
        }
        seekBar.setOnSeekBarChangeListener(Player.this);
        seekBar.setMax(mediaPlayer.getDuration());
        mediaPlayer.start();
        setPlay();
        new Thread() {
            public void run() {
                if(mediaPlayer!=null)
                {
                    while (mediaPlayer.getCurrentPosition() != mediaPlayer.getDuration()) {
                        seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    }

                }
            }

        }.start();
        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count == 1) {
                    Toast.makeText(Player.this, "Removed from Favoutites", Toast.LENGTH_SHORT).show();
                    fav.setImageResource(ic_favorite_border_black_24dp);
                    MyDatabase mdd = new MyDatabase(getApplicationContext());
                    String name = msongname;
                    mdd.doDelete(name);
                    count = 0;
                } else {
                    Toast.makeText(Player.this, "Added to Favoutites", Toast.LENGTH_SHORT).show();
                    fav.setImageResource(ic_favorite_black_24dp);
                    MyDatabase mdd = new MyDatabase(getApplicationContext());
                    String name = msongname;
                    File song = mysongs.get(position);
                    mdd.addSong(name, song, position);
                    count = 1;
                }
            }
        });
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                playNext();
            }
        });

    }
    public void playPrevious()
    {

        //Toast.makeText(this, "ishan", Toast.LENGTH_SHORT).show();
        position=position-1;
        msongname=mysongs.get(position).getName();
        mediaPlayer.pause();
        mediaPlayer.stop();
        MyDatabase md = new MyDatabase(Player.this);
        ArrayList<String> arrayList = md.showSongs();
        if (arrayList.contains(msongname)) {
            fav.setImageResource(ic_favorite_black_24dp);
            count = 1;
        } else {
            fav.setImageResource(ic_favorite_border_black_24dp);
            count = 0;
        }
        //mediaPlayer=new MediaPlayer()
        tv.setText(msongname);
        tv.setSelected(true);
        Uri uri = Uri.parse(mysongs.get(position).toString());
        mediaPlayer = MediaPlayer.create(Player.this, uri);
        //mediaPlayer.start();

        if (mediaPlayer != null) {
            String y = (ConvertToDuration(mediaPlayer.getDuration()));
            timeend.setText(y);
            // Toast.makeText(this, ""+y, Toast.LENGTH_SHORT).show();
        }
        seekBar.setOnSeekBarChangeListener(Player.this);
        seekBar.setMax(mediaPlayer.getDuration());
        mediaPlayer.start();
        setPlay();
        new Thread() {
            public void run() {
                if(mediaPlayer!=null)
                {
                    while (mediaPlayer.getCurrentPosition() != mediaPlayer.getDuration()) {
                        seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    }

                }
            }

        }.start();
        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count == 1) {
                    Toast.makeText(Player.this, "Removed from Favoutites", Toast.LENGTH_SHORT).show();
                    fav.setImageResource(ic_favorite_border_black_24dp);
                    MyDatabase mdd = new MyDatabase(getApplicationContext());
                    String name = msongname;
                    mdd.doDelete(name);
                    count = 0;
                } else {
                    Toast.makeText(Player.this, "Added to Favoutites", Toast.LENGTH_SHORT).show();
                    fav.setImageResource(ic_favorite_black_24dp);
                    MyDatabase mdd = new MyDatabase(getApplicationContext());
                    String name = msongname;
                    File song = mysongs.get(position);
                    mdd.addSong(name, song, position);
                    count = 1;
                }
            }
        });
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                playNext();
            }
        });
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
       // Toast.makeText(this, "ishan", Toast.LENGTH_SHORT).show();
        playNext();
    }
}
