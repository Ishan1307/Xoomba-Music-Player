package com.example.xoomba;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;


public class all extends Fragment {
    ListView lv;
    String[] ar;
    ArrayAdapter<String> adapter;
    public View onCreateView(LayoutInflater inflater,ViewGroup vg,Bundle savedInstanceState)
    {
        View view=inflater.inflate(R.layout.fragment_all,vg,false);
        return view;
    }
}
