package com.example.xoomba;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class SongData extends SQLiteOpenHelper {
    private static String dbname="mysong";
    private static int version=1;
    Context ct;
    SongData(Context ct)
    {
        super(ct,dbname,null,version);
        this.ct=ct;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String s="create table song(mode integer)";
        db.execSQL(s);
    }
    public void settmode(int mode)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("mode",mode);
        db.insert("song",null,cv);
    }
    public ArrayList<Integer> getmode()
    {
        SQLiteDatabase db=getReadableDatabase();
        String s="select * from song";
        Cursor cr=db.rawQuery(s,null);
        ArrayList<Integer> arrayList=new ArrayList<>();
        while (cr.moveToNext())
        {
            String s1=cr.getString(0);
            int x=Integer.parseInt(s1);
            arrayList.add(x);
        }

        return arrayList;
    }
    public void doDelete(int mode)
    {
        SQLiteDatabase db=getWritableDatabase();
        String where="mode=?";
        int x=mode;
        String s1=Integer.toString(x);
        String [] ss={s1};//,s1
        db.delete("song",where,ss);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
