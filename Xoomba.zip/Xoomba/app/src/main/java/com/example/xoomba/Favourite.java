package com.example.xoomba;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.util.ArrayList;

public class Favourite extends AppCompatActivity {

    Button b1;
    ListView lv;
    RelativeLayout relativeLayout;
    ArrayList<String> al;
    ArrayList<File> audiosongs;
    androidx.appcompat.widget.SearchView sv;
    MyDatabase md;
    int x;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);
        b1=findViewById(R.id.allbutton);
        relativeLayout=findViewById(R.id.rl2);
        lv=findViewById(R.id.lv1);
        sv=findViewById(R.id.ser1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Favourite.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        md=new MyDatabase(getApplicationContext());
        al=md.showSongs();
        adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,al);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(Player.mediaPlayer!=null)
                {
                    Player.mediaPlayer.pause();
                    Player.mediaPlayer.stop();
                }
                MyDatabase md=new MyDatabase(getApplicationContext());
                String name=lv.getItemAtPosition(position).toString();
                audiosongs=md.getSong();
                Intent intent=new Intent(Favourite.this,Player.class);
                intent.putExtra("song",audiosongs);
                intent.putExtra("name",name);
                intent.putExtra("pos",position);
                startActivity(intent);
            }
        });
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                lv.setAdapter(adapter);

                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String name=lv.getItemAtPosition(position).toString();
                        audiosongs=md.getSong();
                       x=songposition(name);
                       Intent intent=new Intent(Favourite.this,Player.class);
                        intent.putExtra("song",audiosongs);
                        intent.putExtra("name",name);
                        intent.putExtra("pos",x);
                        startActivity(intent);

                    }
                });
                return false;
            }
        });

    }
    public int songposition(String name)
    {
        int y=0;
        int i;
        String ar[]=new String[al.size()];
        for(i=0;i<al.size();i++)
        {
            ar[i]=al.get(i);
        }
        for(i=0;i<al.size();i++)
        {
            if(name.equals(ar[i]))
            {
                y=i;
            }
        }
        return y;
    }
}
