package com.example.xoomba;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class MyDatabase extends SQLiteOpenHelper {
    private static String dbname="mydatabase";
    private static int version=1;
    Context ct;
    MyDatabase(Context ct)
    {
        super(ct,dbname,null,version);
        this.ct=ct;
    }
    public void addSong(String s1, File s2, int i)
    {
        SQLiteDatabase db=getWritableDatabase();

        ContentValues cv=new ContentValues();
        cv.put("songname",s1);
        cv.put("song", String.valueOf(s2));
        cv.put("position",i);
        db.insert("favour",null,cv);
        Toast.makeText(ct, "Song Added To Favourites", Toast.LENGTH_SHORT).show();

    }
    public ArrayList<String> showSongs()
    {
        SQLiteDatabase db=getReadableDatabase();
        String s="select * from favour";
        Cursor cr=db.rawQuery(s,null);
        ArrayList<String> al=new ArrayList<>();
        while (cr.moveToNext())
        {
            String s1=cr.getString(0);
            al.add(s1);
        }
        return al;
    }
    public ArrayList<File> getSong()
    {
        SQLiteDatabase db=getReadableDatabase();
        String s="select * from favour";
        Cursor cr=db.rawQuery(s,null);
        ArrayList<File> al=new ArrayList<>();
        while (cr.moveToNext())
        {
            String s1=cr.getString(1);
            al.add(new File(String.valueOf(s1)));
        }
        return al;
    }
    public void doDelete(String name)
    {
        SQLiteDatabase db=getWritableDatabase();
        String where="songname=?";
        String [] ss={name};//,s1
        db.delete("favour",where,ss);
        Toast.makeText(ct, "Deletion Completed", Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String s="create table favour(songname text,song text,position integer)";
        db.execSQL(s);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
