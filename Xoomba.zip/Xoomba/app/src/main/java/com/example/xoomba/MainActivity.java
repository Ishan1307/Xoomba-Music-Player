package com.example.xoomba;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener  {

   public ListView lv;
    View v1;
    RelativeLayout relativeLayout;
    androidx.appcompat.widget.SearchView sv;
    SpeechRecognizer speechRecognizer;
    Intent speechrecognizerintent;
    String[] ar;
    String keeper="";
    ArrayAdapter<String> adapter;
    Button all,fav;
    public SongData songData;
    int counter =0;
    int x=0;
    public MediaPlayer mediaPlayer;
    ArrayList<File> audiosongs=new ArrayList<>();
     ArrayAdapter<File> adapter1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sv=findViewById(R.id.ser);
        lv=findViewById(R.id.lv1);
        all=findViewById(R.id.allbutton);
        fav=findViewById(R.id.favbutton);
        relativeLayout=findViewById(R.id.relative);
        appExternalStorage();
        songData=new SongData(getApplicationContext());
        songData.doDelete(1);
        songData.doDelete(0);
        audiosongs=readOnlyAudio(Environment.getExternalStorageDirectory());
        ar=new String[audiosongs.size()];
        for(int songcounter=0;songcounter<audiosongs.size();songcounter++)
        {
            ar[songcounter]=audiosongs.get(songcounter).getName();
        }
        adapter1=new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_list_item_1,audiosongs);
        adapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,ar);
        lv.setAdapter(adapter);
       lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               if(Player.mediaPlayer!=null)
               {
                   Player.mediaPlayer.pause();
                   Player.mediaPlayer.stop();
               }
                String name=lv.getItemAtPosition(position).toString();
                int x;
                ArrayList<Integer> arrayList=songData.getmode();
                Intent intent=new Intent(MainActivity.this,Player.class);
                intent.putExtra("song",audiosongs);
                intent.putExtra("name",name);
                intent.putExtra("pos",position);
                startActivity(intent);

            }
        });
        /*lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                Snackbar snackbar=Snackbar.make(relativeLayout,"Add this song to Favourites",Snackbar.LENGTH_LONG);
                snackbar.setAction("Yes", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        MyDatabase md=new MyDatabase(getApplicationContext());
                        String name=lv.getItemAtPosition(position).toString();
                        File song=audiosongs.get(position);
                        md.addSong(name,song,position);
                    }
                });
                snackbar.show();
                return false;
            }
        });*/
        //appAudioRecording();
        speechRecognizer=SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
        speechrecognizerintent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechrecognizerintent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechrecognizerintent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                adapter1.getFilter().filter(newText);
                lv.setAdapter(adapter);

                lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String name=lv.getItemAtPosition(position).toString();
                        x=songposition(name);
                        ArrayList<Integer> arrayList=songData.getmode();
                        // x=arrayList.get(arrayList.size()-1);
                        //Toast.makeText(MainActivity.this, ""+x, Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(MainActivity.this,Player.class);
                        intent.putExtra("song",audiosongs);
                        intent.putExtra("name",name);
                        intent.putExtra("pos",x);
                        startActivity(intent);

                    }
                });
                return false;
            }
        });

        sv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                        speechRecognizer.startListening(speechrecognizerintent);
                        keeper="";
                        break;
                    case MotionEvent.ACTION_UP:
                        speechRecognizer.stopListening();
                        break;
                }
                return false;
            }
        });
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {

            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float rmsdB) {

            }

            @Override
            public void onBufferReceived(byte[] buffer) {

            }

            @Override
            public void onEndOfSpeech() {

            }

            @Override
            public void onError(int error) {

            }

            @Override
            public void onResults(Bundle results) {
                final ArrayList<String> match=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(match!=null)
                {
                    keeper=match.get(0);
                    //Toast.makeText(MainActivity.this, ""+keeper, Toast.LENGTH_SHORT).show();
                    sv.setQuery(keeper,true);

                }


            }

            @Override
            public void onPartialResults(Bundle partialResults) {

            }

            @Override
            public void onEvent(int eventType, Bundle params) {

            }
        });
    }
    public void appExternalStorage()
    {
        Dexter.withActivity(this)
                .withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.RECORD_AUDIO)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {

                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).onSameThread().check();
        all.setOnClickListener(this);
        fav.setOnClickListener(this);

    }
    public ArrayList<File> readOnlyAudio(File file)
    {
        ArrayList<File> arrayList=new ArrayList<>();
        File[] allFiles=file.listFiles();
        for(File individual:allFiles)
        {
            if(individual.isDirectory()&&!individual.isHidden())
            {
                arrayList.addAll(readOnlyAudio(individual));
            }
            else {
                if(individual.getName().endsWith(".mp3")||individual.getName().endsWith(".aac")||individual.getName().endsWith(".wav"))
                {
                    arrayList.add(individual);
                }
            }
        }
        return arrayList;
    }

    @Override
    public void onClick(View v) {
        Fragment fragment;
        switch (v.getId())
        {
            case R.id.allbutton:
                Toast.makeText(this, "ishan", Toast.LENGTH_SHORT).show();
                break;
            case R.id.favbutton:
                Intent intent=new Intent(this,Favourite.class);
                startActivity(intent);
                finish();
                break;
        }
    }
    public int songposition(String name)
    {
        int y=0;
        int i;
        for(i=0;i<audiosongs.size();i++)
        {
            if(name.equals(ar[i]))
            {
                y=i;
            }
        }
        return y;
    }

    /*

     */
}
